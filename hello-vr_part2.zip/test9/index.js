import React, { Component, Fragment } from 'react';
import {
 AppRegistry,
 StyleSheet,
 Text,
 View,
 VrButton,
 NativeModules,
 Location,
 asset,
} from 'react-360';
import Entity from 'Entity';
import {EmojiText, registerKeyboard} from './react-360-keyboard';

type State = {|
  name: ?string,
|};

class hello_vr1 extends React.Component {
 render() {
   return (     
     <View>
        <View>          
            <Text style={styles.greeting}>You've clicked me.</Text>
        </View>
      </View>
   );
 }
};


class hello_vr extends React.Component {
 render() {
   return (     
     //<View style={styles.panel}>
     <View onInput={e => {
  const event = e.nativeEvent; // Extract the value from the runtime
  // event contains the actual event payload, as well as information on
  // which cursor the user was using, and which React tag was targeted
  const inputEvent = event.inputEvent; // Extract the payload
  // inputEvent.button is the raw button index, used to determine what was pressed
  // inputEvent.buttonClass is a field added to some buttons for common actions,
  //   like 'confirm', 'back', 'up', 'down', etc.
  // inputEvent.action is 'up', 'down', or 'repeat'
  // inputEvent.source identifies the button device, such as keyboard, mouse, etc
}}>
  { /* ... */ }
		<Text style={styles.greeting}>Hi Timken.</Text>
       <Entity
       source={{ obj: asset('Bruno.obj'),
       mtl: asset('Bruno.mtl'),
       png: asset('Bruno.png'),
       }}
       style={{
         transform: [
           {translate: [0, 1, 1]},
           {scale: 1.7},
           {rotateX: 0},
           {rotateY: -90},
           {rotateZ: 0},
         ]
       }}
       />
        <Entity
       source={{ obj: asset('female.obj'),
       mtl: asset('female.mtl'),
       png: asset('female_Body_Diffuse.png'),
       png: asset('female_Bottom_Diffuse.png'),
       png: asset('female_Bottom_Specular.png'),
       png: asset('female_Shoes_Diffuse.png'),
       png: asset('female_Shoes_Specular.png'),
       png: asset('female_Top_Diffuse.png'),
       png: asset('female_Top_Specular.png'),
       png: asset('female_Body_Specular.png'),

       }}
       style={{
         transform: [
           {translate: [-7, 0.8, 1]},
           {scale: 0.02},
           {rotateX: 0},
           {rotateY: 90},
           {rotateZ: 0},
         ]
       }}
       />
     </View>
   );
 }
};



export class Keyboard360 extends React.Component<{||}, State> {
  state = {
    name: null,
  };
  onClick = () => {
    NativeModules.Keyboard.startInput({
      initialValue: this.state.name,
      placeholder: 'Start VR Chatting',
      emoji: true,
    }).then(name => {
      console.log(name);
      this.setState({name});
    });
  };
  render() {
    return (
    <Fragment>
      <VrButton style={styles.greetingBox} onClick={this.onClick}>
        <EmojiText style={styles.greeting}>
          {this.state.name || 'Welcome to HelloVR App'}
        </EmojiText>
      </VrButton>

      <VrButton style={styles.greetingBox} onClick={this.onClick}>
        <EmojiText style={styles.greeting}>
          {this.state.name || ' Start the Chat'}
        </EmojiText>
      </VrButton>
      </Fragment>
    );
  }
}

const styles = StyleSheet.create({
  greetingBox: {
    marginLeft: 350,
    marginTop: 50,
    padding: 20,
    backgroundColor: '#000000',
    borderColor: '#639dda',
    borderWidth: 6,
  },
   greetingBox: {
    marginLeft: 350,
    marginTop: 50,
    padding: 20,
    backgroundColor: '#000000',
    borderColor: '#639dda',
    borderWidth: 6,
  },
  greeting: {
    fontSize: 30,
  },
});

AppRegistry.registerComponent('Keyboard360', () => Keyboard360);
AppRegistry.registerComponent(...registerKeyboard);
AppRegistry.registerComponent('hello_vr', () => hello_vr);
AppRegistry.registerComponent('hello_vr1', () => hello_vr1);
