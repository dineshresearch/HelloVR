import KeyboardComponent from './Keyboard';
import ET from './EmojiText';

export const registerKeyboard = ['KeyboardPanel', () => KeyboardComponent];
export const EmojiText = ET;
